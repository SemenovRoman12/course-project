export interface ReviewEntity {
  id: number;
  name: string;
  description: string;
  rating: number;
}
