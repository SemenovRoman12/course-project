import {reviewsFeature} from './reviews.reducer';

export const {selectReviews, selectReviewsStatus} = reviewsFeature;
