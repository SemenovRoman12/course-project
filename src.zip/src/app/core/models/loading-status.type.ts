export type LoadingStatus = 'init' | 'loading' | 'loaded' | 'error';
