export const environment = {
  api_url: 'https://6d8a39e70ba8753e.mokky.dev',
};
